"""
Search and find the words in the table

Arguments:

-c (--colored): whether or not the output is colored (yes or no)
-h (--help): display this help
"""

# importing builtin and external libraries
import argparse
import sys
from termcolor import colored

"""
Function `checkWord()`

Parameters:
    word: the word to find
    j: row index of the position of the letter in the table
    k: column index of the position of the letter in the table
    row: steps to do horizontally [-1, 0 or 1] (-1: upward, 0: same row, 1 downward)
    column: steps to do vertically [-1, 0 or 1] (-1: backward, 0: same column, 1 forward)
"""
def checkWord(word, j, k, row, column):
    step = 1
    counter = 0
    # use the found_letters and color_index defined in the main from inside this function
    global found_letters, color_index
    
    # loop in the direction specified by the variables `row` and `column`, 
    # until step reaches 0 (if going backward or downward), or step reaches the size of the row or column (otherwise)
    while step < len(word) and j+(row*step) < len(table) and k+(column*step) < len(table[j]) and j+(row*step) >= 0 and k+(column*step) >= 0:
        if(table[j+(row*step)][k+(column*step)] is word[step]):
            counter = counter + 1
        step = step + 1
    # if the counter is equal to the length of the word, then the word exists in the table
    # below is a step in order to print the table with highlighting the word
    # we will save the indexes of the letters in another array, along with the index of the color
    if counter is len(word)-1:
        for step in range(len(word)):
            found_letters.append([j+(row*step), k+(column*step), color_index % len(colors_list)])
        color_index = color_index + 1
        return True
    return False



# The script starts here at the main function 
if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Prints highlighted output')
    parser.add_argument('-c','--colored', help='whether the output supports colored')
    args = parser.parse_args()
    
    # initialize the words array
    words = ["ALLIGATOR","MONKEY","BEAR","CHEETAH","LION","COW","CROCODILE","ELEPHANT","DOG","CAT","GOAT","FROG","RAT","MOUSE","PENGUIN","GIRAFFE","PANDA","TIGER","TURTLE","DOLPHIN"]
    
    # initialize the table in 2-dimensional array
    table = [
    ["T","G","C","P","N","I","H","P","L","O","D","F","P","I"],
    ["H","N","E","I","N","T","F","G","P","A","N","D","A","M"],
    ["A","F","H","L","R","A","U","N","I","U","G","N","E","P"],
    ["T","C","R","P","R","I","O","R","T","I","G","E","R","L"],
    ["?","?","?","O","G","O","?","?","?","?","?","?","?","D"],
    ["E","P","R","I","G","A","I","O","F","L","L","E","S","O"],
    ["H","L","L","Y","O","D","O","A","I","F","E","I","U","G"],
    ["C","O","E","G","T","N","C","D","G","P","A","H","O","P"],
    ["T","M","F","P","I","O","O","A","L","I","L","R","M","O"],
    ["B","O","M","L","H","C","W","O","I","N","L","O","I","R"],
    ["E","N","E","C","O","A","D","O","O","T","I","L","N","G"],
    ["A","K","E","R","E","E","N","I","I","S","C","R","A","G"],
    ["R","E","C","H","R","R","L","I","I","E","F","O","D","N"],
    ["I","Y","E","R","A","T","A","N","A","T","N","R","L","B"]
    ]
    
    found_letters = [] # array to save found letters
    colors_list = ['red','green','yellow','magenta','cyan'] # list of colors to be used in the output
    color_index = 0 # color index
    for i in range(len(words)): # loop over the words list
        word = words[i] # assign current word to search for to the variable `word`
        for j in range(len(table)): # loop over the rows in the table
            row = table[j] # assign current row of the table to the variable `row`
            for k in range(len(row)): # loop over the letters in the row
                if(row[k] is word[0]): # check if current letter matches the first letter of the word we're searching for
                    # if a letter in the table matches the first letter of a word, we need to check in any direction if we can find the whole word
                    # with that in mind, we will test the return of the function checkWord...(word, j, k) in all directions
                    # if the function returns true, then the word exists in the table in that direction, else the word does not exists then nothing to do
                    checkWord(word, j, k, 0, 1)     # Forward (same row, next columns)
                    checkWord(word, j, k, 0, -1)    # Backward (same row, previous colums)
                    checkWord(word, j, k, 1, 0)     # Downward (next rows, same column)
                    checkWord(word, j, k, -1, 0)    # Upward (previous rows, same column)
                    checkWord(word, j, k, 1, 1)     # Upward Forward (next rows, next columns)
                    checkWord(word, j, k, 1, -1)    # Upward Backward (next rows, previous columns)
                    checkWord(word, j, k, -1, 1)    # Downward Forward (previous rows, next columns)
                    checkWord(word, j, k, -1, -1)   # Downward Backward (previous rows, previous columns)

    # display the table with found words highlighted by a color or by the symbol `>` BEFORE each letter
    for i in range(len(table)): # loop over the rows in the table
        for j in range(len(table[i])): # loop over the letters in the row
            found = False
            for k in range(len(found_letters)): # check if any letter in word is in this position
                if found_letters[k][0] == i and found_letters[k][1] == j and not found:
                    if args.colored == "yes":
                        print(" " + colored( table[i][j], colors_list[found_letters[k][2]] ),end = '')
                    elif args.colored == "no":
                        print(">" + table[i][j], end = '')
                    else:
                        print(" " + table[i][j], end = '')
                    found = True
            if not found: # if nothing found print the letter normally
                if args.colored == "yes":
                    print(" " + table[i][j] , end = '')
                elif args.colored == "no":
                    print(" " + table[i][j] , end = '')
                else:
                    print(" ", end = ' ')
        print()